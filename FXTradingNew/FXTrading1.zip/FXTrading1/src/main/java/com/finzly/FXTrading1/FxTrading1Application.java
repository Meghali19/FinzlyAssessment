package com.finzly.FXTrading1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FxTrading1Application {

	public static void main(String[] args) {
		SpringApplication.run(FxTrading1Application.class, args);
	}

}
