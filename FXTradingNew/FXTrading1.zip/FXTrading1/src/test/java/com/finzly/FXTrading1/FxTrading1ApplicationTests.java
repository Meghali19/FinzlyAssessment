package com.finzly.FXTrading1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FxTrading1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
